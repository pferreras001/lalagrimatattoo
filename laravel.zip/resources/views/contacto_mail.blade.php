<!DOCTYPE html>
<htlm lang="es">
<head>
    <meta charset="utf-8">
    <h1>¡Tienes un nuevo mensaje de contacto de <a href="mailto:{{$email}}">{{$email}}!</a></h1>
</head>
<body>
    <p>{{$mensaje}}</p>
</body>
</htlm>