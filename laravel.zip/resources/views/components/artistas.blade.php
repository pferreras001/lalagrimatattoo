<section class="section artistas" id="artistas">
  <div class="container artistas__container">
    <h1 align="right">artistas.</h1>
    <div class="artistas__profiles">
      <a href="https://www.instagram.com/manucolladottt/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Manu Collado.</li>
            <li>ornamental y japonés.</li>
            <li>@manucolladottt</li>
          </ul>
          <div>
            <img class="artistas__img" src="img/artistas/manu.jpg"/>
          </div>
        </div>
      </a>
      <a href="https://www.instagram.com/rwellstattoo/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Rachel Wells.</li>
            <li>tradicional y japonés.</li>
            <li>@rwellstattoo</li>
          </ul>
          <div>
            <img class="artistas__img " src="img/artistas/reichel.jpg"/>
          </div>
        </div>
      </a>
      <a href="https://www.instagram.com/noetattoos/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Noemi Millet.</li>
            <li>geometrías, ornamental y neotribal.</li>
            <li>@noetattoos</li>
          </ul>
          <div>
            <img class="artistas__img " src="img/artistas/noe.jpg"/>
          </div>
        </div>
      </a>
      <a href="https://www.instagram.com/domifuentes.tattoo/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Domi Fuentes.</li>
            <li>blackwork y fineline.</li>
            <li>@domifuentes.tattoo</li>
          </ul>
          <div>
            <img class="artistas__img " src="img/artistas/domi.jpg"/>
          </div>
        </div>
      </a>
      <a href="https://www.instagram.com/saraanaut/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Sara Anaut.</li>
            <li>neotradicional y acuarela.</li>
            <li>@saraanaut</li>
          </ul>
          <div>
            <img class="artistas__img " src="img/artistas/sara.jpg"/>
          </div>
        </div>
      </a>
      <a href="https://www.instagram.com/marek.koprowski.tattoo/" target="_blank">
        <div class="artistas__profile">
          <ul class="artistas__info">
            <li>Marek Koprowski.</li>
            <li>ornamental y tradicional.</li>
            <li>@marek.koprowski.tattoo</li>
          </ul>
          <div>
            <img class="artistas__img " src="img/artistas/marek.jpg"/>
          </div>
        </div>
      </a>
    </div>
  </div>
</section>