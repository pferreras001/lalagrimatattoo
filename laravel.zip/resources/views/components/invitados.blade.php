<section data-aos="fade-left" class="section invitados">
  <div class="invitados__container">
    <div class="invitados__left">
      <img src="img/invitados/background.png">
    </div>
    <div class="invitados__right">
      Contamos con los mejores<br>
      ARTISTAS INVITADOS
    </div>
  </div>
</section>