<section class="section despedida">
  <div class="despedida__container">
    <div class="despedida__left">
      Si quieres llevarte un buen recuerdo para toda la vida, pásate a conocernos y a pincharte. Al
      fin y al cabo <br>
      THIS IS A TATTOO PLACE
    </div>
    <div class="despedida__right">
      <img src="img/despedida/background.png">
    </div>
  </div>
</section>