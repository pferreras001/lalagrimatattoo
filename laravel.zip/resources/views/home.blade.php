@extends('layout')

@section('section')

<x-home/>
<x-trabajos/>
<x-artistas/>
<x-invitados/>
<x-contacto/>
<x-despedida/>

@endsection