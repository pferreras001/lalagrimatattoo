<section class="section trabajos">
  <div class="container trbajos__container" data-aos="fade-up">
    <h1 class="title">trabajos.</h1>
    <div class="trabajos__images">
      <h3>Manu Collado.</h3>
      <div>
        <img src="img/trabajos/manu/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/manu/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/manu/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/manu/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
      <h3>Rachel Wells.</h3>
      <div>
        <img src="img/trabajos/reichel/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/reichel/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/reichel/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/reichel/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
      <h3>Noemi Millet.</h3>
      <div>
        <img src="img/trabajos/noe/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/noe/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/noe/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/noe/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
      <h3>Domi Fuentes.</h3>
      <div>
        <img src="img/trabajos/domi/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/domi/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/domi/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/domi/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
      <h3>Sara Anaut.</h3>
      <div>
        <img src="img/trabajos/sara/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/sara/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/sara/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/sara/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
      <h3>Marek Koprowski.</h3>
      <div>
        <img src="img/trabajos/marek/1.jpg" data-aos="fade-right"/>
        <img src="img/trabajos/marek/2.jpg" data-aos="fade-up" data-aos-delay="100"/>
        <img src="img/trabajos/marek/3.jpg" data-aos="fade-up" data-aos-delay="200"/>
        <img src="img/trabajos/marek/4.jpg" data-aos="fade-up" data-aos-delay="300"/>
      </div>
    </div>
  </div>
</section><?php /**PATH /Users/admin/Documents/web_proyects/laravel/la_lagrima/resources/views/components/trabajos.blade.php ENDPATH**/ ?>