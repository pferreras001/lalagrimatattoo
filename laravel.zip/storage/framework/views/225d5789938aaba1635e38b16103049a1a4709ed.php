<!DOCTYPE html>
<htlm lang="es">
<head>
    <meta charset="utf-8">
    <h1>¡Tienes un nuevo mensaje de contacto de <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?>!</a></h1>
</head>
<body>
    <p><?php echo e($mensaje); ?></p>
</body>
</htlm><?php /**PATH /Users/admin/Documents/web_proyects/laravel/la_lagrima/resources/views/contacto_mail.blade.php ENDPATH**/ ?>