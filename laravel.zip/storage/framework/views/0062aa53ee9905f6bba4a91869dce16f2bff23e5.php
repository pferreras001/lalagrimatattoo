<?php $__env->startSection('section'); ?>

<?php if (isset($component)) { $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home::class, []); ?>
<?php $component->withName('home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73)): ?>
<?php $component = $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73; ?>
<?php unset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal05bee0106833361dfc7ef4bb7b64fe0fec0c9705 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Trabajos::class, []); ?>
<?php $component->withName('trabajos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05bee0106833361dfc7ef4bb7b64fe0fec0c9705)): ?>
<?php $component = $__componentOriginal05bee0106833361dfc7ef4bb7b64fe0fec0c9705; ?>
<?php unset($__componentOriginal05bee0106833361dfc7ef4bb7b64fe0fec0c9705); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal53c8dd4f80f53194cf35350d69d3e753f7e2eb4a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artistas::class, []); ?>
<?php $component->withName('artistas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53c8dd4f80f53194cf35350d69d3e753f7e2eb4a)): ?>
<?php $component = $__componentOriginal53c8dd4f80f53194cf35350d69d3e753f7e2eb4a; ?>
<?php unset($__componentOriginal53c8dd4f80f53194cf35350d69d3e753f7e2eb4a); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal1baee47a2958893159e9ec100992a17cdc0de598 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Invitados::class, []); ?>
<?php $component->withName('invitados'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1baee47a2958893159e9ec100992a17cdc0de598)): ?>
<?php $component = $__componentOriginal1baee47a2958893159e9ec100992a17cdc0de598; ?>
<?php unset($__componentOriginal1baee47a2958893159e9ec100992a17cdc0de598); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Contacto::class, []); ?>
<?php $component->withName('contacto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6)): ?>
<?php $component = $__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6; ?>
<?php unset($__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal01b6f0024d94b4c8ae37f5f813db4bc1857ce83c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Despedida::class, []); ?>
<?php $component->withName('despedida'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b6f0024d94b4c8ae37f5f813db4bc1857ce83c)): ?>
<?php $component = $__componentOriginal01b6f0024d94b4c8ae37f5f813db4bc1857ce83c; ?>
<?php unset($__componentOriginal01b6f0024d94b4c8ae37f5f813db4bc1857ce83c); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/lalagrimatattoo/resources/views/home.blade.php ENDPATH**/ ?>