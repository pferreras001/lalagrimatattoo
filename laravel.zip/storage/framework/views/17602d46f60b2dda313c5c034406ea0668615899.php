<section class="section home" data-aos="fade-up">
  <div class="container home__container">
    <img src="img/home/logo.png"/>
    <h1>La Lágrima</h1>
    <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
  </div>
</section><?php /**PATH /Users/admin/Documents/web_proyects/laravel/la_lagrima/resources/views/components/home.blade.php ENDPATH**/ ?>